<?php
ob_start();
require_once '../library/lib.php';

$lib=new Lib;

$lib->logout();
?>

