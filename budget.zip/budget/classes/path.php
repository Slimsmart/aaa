<?php
$site='http://localhost/mymodel/';
$img_path='../images/';

$vehicle_path='http://localhost/dl/vehicle.php';


?>

