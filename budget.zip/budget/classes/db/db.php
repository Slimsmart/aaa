<?php
define('DB_SERVER', 'localhost');
define('DB_NAME', 'budget');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

?>

